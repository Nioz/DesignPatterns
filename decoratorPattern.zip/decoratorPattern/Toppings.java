package decoratorPattern;

public abstract class Toppings extends IceCream {
	public IceCream iceCream;
	
	public abstract String getDescription();

}
