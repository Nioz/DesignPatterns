package duckyP;

public class FlyNoWay implements FlyBehavior{
	
	public void fly() {
		System.out.println("Ich kann nichte fliegen!");
	}
	
}
