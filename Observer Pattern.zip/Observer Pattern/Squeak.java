package duckyP;

public class Squeak implements QuackBehavior {
	
	public void quack() {
		System.out.println("*You squeeze the duck and the most horryfing cry you have ever heard leaves its bill*");
	}

}
